﻿using AppProjetoEscola.RegrasDeNegocio;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProjetoEscola.ReagrasDeNegocio
{
    public class SalaDeAula
    {
        //atributos
        public int Id { get; set; }
        public int Serie { get; set; }
        public string NomeTurma { get; set; }

        public List<Aluno> AlunosMatriculados { get; set; }
        

        //MétodoConstrutor
        public SalaDeAula(int id, int Serie, string NomeTurma)
        {
            this.Id = id;
            this.Serie = Serie;
            this.NomeTurma = NomeTurma;

            AlunosMatriculados = new List<Aluno>();
        }
    }
}
