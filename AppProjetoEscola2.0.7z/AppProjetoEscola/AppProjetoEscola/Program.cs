﻿using AppProjetoEscola.RegrasDeNegocio;

List<SalaDeAula> salasDeAula = new List<SalaDeAula>();
int opc = 1;
int contador = 1;

void CadastrarTurma()
{
    int opcao = 1;
    while (opcao != 0)
    {
        Console.Clear();
        Console.WriteLine("-------------------CADASTRAR TURMA-------------------\n");

        Console.Write("SÉRIE....:");
        var serie = Convert.ToInt32(Console.ReadLine());

        Console.Write("NOME DA TURMA....:");
        var nomeTurma = Console.ReadLine();
        SalaDeAula turma = new SalaDeAula(contador, serie, nomeTurma);
        // depois da sala criada, colocar a sala na lista
        salasDeAula.Add(turma);
        contador++;

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("!!!TURMA CRIADA!!!\n");

        Console.ForegroundColor = ConsoleColor.White;
        Console.Write("DESEJA CONTINUAR CADSTRANDO TURMA? (S/N).....:");
        var resposta = Console.ReadLine().ToUpper();

        if(resposta == "N") opcao = 0;
            


    }//fim do While
}

SalaDeAula SelecionarTurma()
{
    Console.Clear();
    Console.WriteLine("-------------------SELECIONAR TURMA-------------------\n");

    Console.Write("NOME DA TURMA....:");
    var nomeTurma = Console.ReadLine().ToUpper();
    var turmaSelecionada = salasDeAula.Where(sala => sala.NomeTurma.ToUpper() == nomeTurma).FirstOrDefault();

    if (turmaSelecionada == null)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("TURMA NÃO ENCONTRADA");
        Console.ReadKey();
    }
    Console.ForegroundColor = ConsoleColor.White;
    return turmaSelecionada;

}

while (opc != 0)
{
    Console.Clear();
    Console.WriteLine("-------------------ESCOLA GOLPE EFICIENTE-------------------\n");

    Console.WriteLine("1 - CADASTRAR TURMA");
    Console.WriteLine("2 - CADASTRAR ALUNO");
    Console.WriteLine("3 - CONSULTAR ALUNO");
    Console.WriteLine("4 - FILTRAR ALUNOS");
    Console.WriteLine("5 - LISTAR ALUNOS APROVADOS");
    Console.WriteLine("6 - LISTAR ALUNOS REPROVADOS");
    Console.WriteLine("7 - LISTAR TODOS OS ALUNOS DA TURMA");
    Console.WriteLine("8 - ESTATÍSTICA DA TURMA");
    Console.WriteLine("9 - LISTAR TODOS OS ALUNOS DA ESCOLA");
    Console.WriteLine("0 - SAIR DO SISTEMA");

    Console.Write("OPÇÃO N°....:");
    opc = Convert.ToInt32(Console.ReadLine());

    switch (opc)
    {
        case 1:
            {
                CadastrarTurma();
                break;
            }
            case 2:
            {
                salasDeAula.Where(sala => sala == SelecionarTurma()).FirstOrDefault().CadastrarAluno();
                break;
            }
        case 3:
            {
                salasDeAula.Where(sala => sala == SelecionarTurma()).FirstOrDefault().ConsultarAluno();
                break;
            }
        case 4: 
            {
                salasDeAula.Where(sala => sala == SelecionarTurma()).ConsultarAluno().OrderBy<>;
                break;
            }
    }

}//fim do While
