﻿using AppProjetoEscola.RegrasDeNegocio;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProjetoEscola.RegrasDeNegocio
{
    public class SalaDeAula
    {
        //atributos
        public int Id { get; set; }
        public int Serie { get; set; }
        public string NomeTurma { get; set; }

        public List<Aluno> AlunosMatriculados { get; set; } // estou criando uma list da classe Aluno e nomeando como AlunosMatriculados

        int opcao = 1;

        //MétodoConstrutor
        public SalaDeAula(int id, int serie, string nomeTurma)
        {
            this.Id = id;
            this.Serie = serie;
            this.NomeTurma = nomeTurma;

            AlunosMatriculados = new List<Aluno>();
        }
        public void CadastrarAluno()
        {
            
           while (opcao != 0)
           {
                Console.Clear();
                Console.WriteLine("-------------------CADASTRAR ALUNO-------------------\n");

                Aluno aluno = new Aluno();
                aluno.Id = AlunosMatriculados.Count + 1;
                aluno.NumeroDaMatricula = AlunosMatriculados.Count + 1000;

                Console.Write("Nome....................................:");
                aluno.Nome = Console.ReadLine(); //inserindo nome do aluno

                Console.Write("Nota1....................................:");
                aluno.Nota1 = Convert.ToDouble(Console.ReadLine()); //inserindo nota

                Console.Write("Nota2....................................:");
                aluno.Nota2 = Convert.ToDouble(Console.ReadLine()); //inserindo nota

                AlunosMatriculados.Add(aluno); // estou adiconando os dados inserios a list da classe Aluno

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("!!!ALUNO CADASTRADO COM SUCESSO!!!\n");

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Deseja  continuar cadastrando? (S/N)......:");
                var resposta = Console.ReadLine().ToUpper();

                if (resposta == "N") opcao = 0;

           }
        }//Fim do Método CadastrarAluno
        public void ConsultarAluno()
        {
           while (opcao != 0)
           {
                Console.Clear();
                Console.WriteLine("-------------------CONSULTAR ALUNO-------------------\n");
                Console.WriteLine("Série/Turma: "+ Serie+"/"+NomeTurma);

                Console.Write("Nome....................................:");
                var nome = Console.ReadLine().ToUpper(); //.ToUpper() deixa tudo maiusculo
                var aluno = AlunosMatriculados.Where(a => a.Nome.ToUpper() == nome).FirstOrDefault(); //.FirstOrDefault pega o primeiro da lista
                if (aluno != null)
                {
                    Console.WriteLine($"N° MATRICULA....:{aluno.NumeroDaMatricula}");
                    Console.WriteLine($"NOME....:{aluno.Nome}");
                    Console.WriteLine($"NOTA1....:{aluno.Nota1}");
                    Console.WriteLine($"NOTA2....:{aluno.Nota2}");
                    Console.WriteLine($"MÉDIA....:{aluno.CalcularMedia}");
                    Console.WriteLine($"SITUAÇÃO....:{aluno.VerificarSituacao}");

                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("*ALUNO INEXISTENTE*");
                }
                Console.WriteLine();

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Deseja  continuar consultando? (S/N)......:");
                var resposta = Console.ReadLine();

                if (resposta == "N") opcao = 0;

                Console.ReadKey();
           }//fim do While
        }//Fim do Método ConsultarAluno
        public void FiltrarAlunos()
        {           
            Console.Clear();
            Console.WriteLine("Consultar por nome");

            Console.Write("Informe o nome:");
            var nome = Console.ReadLine();
            var nomeAchado = AlunosMatriculados.Where(h => h.Nome.ToUpper().Contains(nome.ToUpper())).ToList();


            if (nomeAchado.Count() < 1)
            {
                Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("!!!INEXISTENTE!!!"); Console.ForegroundColor = ConsoleColor.White;
            }
            foreach (var aluno in nomeAchado)
            {
                Console.WriteLine("\nMatricula do aluno:"+aluno.NumeroDaMatricula);
                Console.WriteLine("Id do aluno:"+aluno.Id);
                Console.WriteLine("Nome do Aluno:"+aluno.Nome);
                Console.WriteLine("Nota1:"+aluno.Nota1);
                Console.WriteLine("Nota2:"+aluno.Nota2);
                Console.WriteLine("Média:"+aluno.CalcularMedia());
                Console.WriteLine("Situação:"+aluno.VerificarSituacao());

            }
            Console.ReadKey();



        }//Fim do Método FiltarAlunos
        public void ListarTodosAlunos()
        {
            foreach (var aluno in AlunosMatriculados.OrderBy(a => a.Nome).ToList())
            {
                Console.WriteLine("\nMatricula do aluno:" + aluno.NumeroDaMatricula);
                Console.WriteLine("Id do aluno:" + aluno.Id);
                Console.WriteLine("Nome do Aluno:" + aluno.Nome);
                Console.WriteLine("Nota1:" + aluno.Nota1);
                Console.WriteLine("Nota2:" + aluno.Nota2);
                Console.WriteLine("Média:" + aluno.CalcularMedia());
                Console.WriteLine("Situação:" + aluno.VerificarSituacao());
            }
            Console.ReadKey();
        }//Fim do Método ListarTodosAlunos
        public void ListarAlunosAprovados()
        {
            foreach (var aluno in AlunosMatriculados)
            {
               if (aluno.VerificarSituacao() == "APROVADO")
                {
                    Console.WriteLine("\nMatricula do aluno:" + aluno.NumeroDaMatricula);
                    Console.WriteLine("Id do aluno:" + aluno.Id);
                    Console.WriteLine("Nome do Aluno:" + aluno.Nome);
                    Console.WriteLine("Nota1:" + aluno.Nota1);
                    Console.WriteLine("Nota2:" + aluno.Nota2);
                    Console.WriteLine("Média:" + aluno.CalcularMedia());
                    Console.WriteLine("Situação:" + aluno.VerificarSituacao());
                }

            }
            Console.ReadKey();

        }//Fim do Método ListarAlunosAprovados
        public void ListarAlunosReprovados()
        {
            foreach (var aluno in AlunosMatriculados)
            {
                if (aluno.VerificarSituacao() != "APROVADO")
                {
                    Console.WriteLine("\nMatricula do aluno:" + aluno.NumeroDaMatricula);
                    Console.WriteLine("Id do aluno:" + aluno.Id);
                    Console.WriteLine("Nome do Aluno:" + aluno.Nome);
                    Console.WriteLine("Nota1:" + aluno.Nota1);
                    Console.WriteLine("Nota2:" + aluno.Nota2);
                    Console.WriteLine("Média:" + aluno.CalcularMedia());
                    Console.WriteLine("Situação:" + aluno.VerificarSituacao());
                }

            }
            Console.ReadKey();
        }//Fim do Método ListarAlunosReprovados
        public void EstatisticaDaTurma()
        {

        }//Fim do Método Estatistica da turma

    }// dim da classe SalaDeAula
}
